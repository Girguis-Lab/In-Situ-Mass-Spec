(librepcb_schematics
 (schematic "schematics/schematic/schematic.lp")
 (schematic "schematics/new_page/schematic.lp")
 (schematic "schematics/atmega16/schematic.lp")
 (schematic "schematics/transceivers/schematic.lp")
)
