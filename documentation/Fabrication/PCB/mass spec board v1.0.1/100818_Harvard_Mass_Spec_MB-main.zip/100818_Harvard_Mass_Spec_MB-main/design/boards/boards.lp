(librepcb_boards
 (board "boards/pcb/board.lp")
)
